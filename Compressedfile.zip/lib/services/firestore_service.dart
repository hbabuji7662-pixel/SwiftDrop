
import 'package:cloud_firestore/cloud_firestore.dart';
final FirebaseFirestore firestore = FirebaseFirestore.instance;

class FirestoreService {
  static Stream<QuerySnapshot> restaurantsStream() => firestore.collection('restaurants').snapshots();
  static Stream<QuerySnapshot> menusStream(String restaurantId) => firestore.collection('menus').where('restaurantId', isEqualTo: restaurantId).snapshots();
  static Future<DocumentReference> placeOrder(Map<String,dynamic> data) => firestore.collection('orders').add(data);
  static Stream<QuerySnapshot> myOrdersStream(String userId) => firestore.collection('orders').where('customerId', isEqualTo: userId).orderBy('createdAt', descending: true).snapshots();
  static Stream<QuerySnapshot> ordersStream() => firestore.collection('orders').orderBy('createdAt', descending: true).snapshots();
}
