
import 'package:firebase_storage/firebase_storage.dart';

class StorageService {
  static final FirebaseStorage storage = FirebaseStorage.instance;

  static Future<String> uploadFile(String path, List<int> bytes) async {
    final ref = storage.ref(path);
    final task = await ref.putData(bytes);
    return await ref.getDownloadURL();
  }
}
