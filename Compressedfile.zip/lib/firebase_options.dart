
/// Replace with generated DefaultFirebaseOptions by running `flutterfire configure`
class DefaultFirebaseOptions {
  static get currentPlatform => throw UnimplementedError('Run `flutterfire configure` and paste generated options here');
}
