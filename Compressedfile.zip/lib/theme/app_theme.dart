
import 'package:flutter/material.dart';

class AppTheme {
  static const Color yellow = Color(0xFFFFD400);
  static const Color black = Color(0xFF0B0B0B);
  static const Color card = Color(0xFF111111);

  static ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: yellow,
    scaffoldBackgroundColor: black,
    appBarTheme: AppBarTheme(
      backgroundColor: black,
      elevation: 0,
      iconTheme: IconThemeData(color: yellow),
      titleTextStyle: TextStyle(color: yellow, fontSize: 20, fontWeight: FontWeight.bold),
    ),
    colorScheme: ColorScheme.dark(primary: yellow, secondary: yellow),
    cardColor: card,
  );
}
