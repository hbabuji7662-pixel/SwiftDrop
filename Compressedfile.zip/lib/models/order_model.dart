
class OrderModel {
  final String id;
  final String customerId;
  final int total;
  final String status;
  OrderModel({required this.id, required this.customerId, required this.total, required this.status});
}
