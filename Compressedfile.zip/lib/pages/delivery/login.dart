
import 'package:flutter/material.dart';
import '../../services/auth_service.dart';
import 'delivery_home.dart';

class DeliveryLogin extends StatefulWidget {
  @override State<DeliveryLogin> createState() => _DeliveryLoginState();
}

class _DeliveryLoginState extends State<DeliveryLogin> {
  final phone = TextEditingController();
  final pass = TextEditingController();
  bool loading=false;
  login() async { setState(()=>loading=true); final user = await AuthService.login(phone.text, pass.text); setState(()=>loading=false); if(user!=null) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_)=>DeliveryHome())); }
  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Delivery Login')), body: Padding(padding: EdgeInsets.all(16), child: Column(children: [TextField(controller: phone, decoration: InputDecoration(labelText:'Phone/Email')), TextField(controller: pass, obscureText:true, decoration: InputDecoration(labelText:'Password')), SizedBox(height:12), ElevatedButton(onPressed: loading?null:login, child: loading?CircularProgressIndicator():Text('Login'))],),));
  }
}
