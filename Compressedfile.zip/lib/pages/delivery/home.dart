
import 'package:flutter/material.dart';

class DeliveryHome extends StatelessWidget {
  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Delivery Dashboard')), body: Center(child: Text('Assigned orders will appear here')));
  }
}
