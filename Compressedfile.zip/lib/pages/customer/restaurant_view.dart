
import 'package:flutter/material.dart';
import '../../services/firestore_service.dart';
import 'menu_view.dart';

class RestaurantView extends StatelessWidget {
  final String id;
  final String name;
  RestaurantView({required this.id, required this.name});

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text(name)), body: StreamBuilder(stream: FirestoreService.menusStream(id), builder: (context,snapshot){
      if(!snapshot.hasData) return Center(child: CircularProgressIndicator());
      final docs = snapshot.data!.docs;
      return ListView.builder(itemCount: docs.length, itemBuilder: (_,i){
        final d = docs[i].data() as Map<String,dynamic>;
        return Card(child: ListTile(title: Text(d['name'] ?? 'Item'), subtitle: Text('₹'+(d['price']?.toString() ?? '0')), trailing: ElevatedButton(onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=>MenuView(item: d))), child: Text('Order'))));
      });
    }),);
  }
}
