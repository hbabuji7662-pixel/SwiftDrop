
import 'package:flutter/material.dart';

class TrackingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Tracking')), body: Center(child: Text('Live tracking placeholder')));
  }
}
