
import 'package:flutter/material.dart';
import '../../services/firestore_service.dart';

class MenuView extends StatefulWidget {
  final Map<String,dynamic> item;
  MenuView({required this.item});
  final qty = 1;
  @override
  State<MenuView> createState() => _MenuViewState();
}

class _MenuViewState extends State<MenuView> {
  final address = TextEditingController();
  bool placing = false;

  placeOrder() async {
    setState(()=>placing=true);
    final data = {
      'customerId':'guest',
      'customerName':'Guest',
      'customerAddress':address.text,
      'items':[widget.item],
      'totalAmount':widget.item['price'] ?? 0,
      'paymentStatus':'COD',
      'orderStatus':'Pending',
      'createdAt': DateTime.now().millisecondsSinceEpoch
    };
    await FirestoreService.placeOrder(data);
    setState(()=>placing=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order placed')));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text(widget.item['name'] ?? 'Item')), body: Padding(padding: EdgeInsets.all(16), child: Column(children: [
      Text('Price: ₹'+(widget.item['price']?.toString() ?? '0')),
      TextField(controller: address, decoration: InputDecoration(labelText: 'Delivery address')),
      SizedBox(height:16),
      ElevatedButton(onPressed: placing?null:placeOrder, child: placing?CircularProgressIndicator():Text('Place Order'))
    ]),),);
  }
}
