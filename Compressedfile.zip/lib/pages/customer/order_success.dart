
import 'package:flutter/material.dart';

class OrderSuccessPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.check_circle, size:100, color: Colors.yellow), SizedBox(height:12), Text('Order placed!'), ElevatedButton(onPressed: ()=> Navigator.popUntil(context,(r)=>r.isFirst), child: Text('Home'))])));
  }
}
