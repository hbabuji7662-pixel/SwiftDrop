
import 'package:flutter/material.dart';
import 'login.dart';

class SplashPage extends StatefulWidget {
  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 1), () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LoginPage())));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Text('SwiftDrop', style: TextStyle(fontSize: 36, color: Colors.yellow))));
  }
}
