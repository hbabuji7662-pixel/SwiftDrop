
import 'package:flutter/material.dart';
import '../../services/auth_service.dart';
import 'admin_home.dart';

class AdminLogin extends StatefulWidget { @override State<AdminLogin> createState() => _AdminLoginState(); }

class _AdminLoginState extends State<AdminLogin> {
  final email = TextEditingController();
  final pass = TextEditingController();
  bool loading=false;
  login() async { setState(()=>loading=true); final user = await AuthService.login(email.text.trim(), pass.text.trim()); setState(()=>loading=false); if(user!=null) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_)=>AdminHome())); }
  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Admin Login')), body: Padding(padding: EdgeInsets.all(16), child: Column(children: [TextField(controller: email, decoration: InputDecoration(labelText:'Email')), TextField(controller: pass, obscureText:true, decoration: InputDecoration(labelText:'Password')), SizedBox(height:12), ElevatedButton(onPressed: loading?null:login, child: loading?CircularProgressIndicator():Text('Login'))],),));
  }
}
