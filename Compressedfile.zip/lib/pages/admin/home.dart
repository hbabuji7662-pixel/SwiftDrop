
import 'package:flutter/material.dart';
import '../../services/firestore_service.dart';

class AdminHome extends StatelessWidget {
  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Admin Panel')), body: StreamBuilder(stream: FirestoreService.ordersStream(), builder:(context,snapshot){
      if(!snapshot.hasData) return Center(child:CircularProgressIndicator());
      final docs = snapshot.data!.docs;
      return ListView.builder(itemCount: docs.length, itemBuilder: (_,i){ final d = docs[i].data() as Map<String,dynamic>; return ListTile(title: Text('Order: '+docs[i].id), subtitle: Text(d['orderStatus'] ?? '')); });
    }),);
  }
}
