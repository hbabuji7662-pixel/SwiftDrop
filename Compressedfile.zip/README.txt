
SwiftDrop Full Delivery App - Skeleton
=====================================

This ZIP contains a complete Flutter project skeleton for a delivery platform with:
- Customer app screens (home, restaurant, menu, checkout, orders, tracking)
- Delivery rider app screens (login, home)
- Admin panel screens (login, orders)
- Firebase integration placeholders (firebase_options.dart)
- Services for Auth, Firestore, Storage (stubs)
- Theme (Black + Yellow)

HOW TO RUN:
1. Extract ZIP.
2. Install Flutter SDK.
3. Run `flutter pub get` in project root.
4. Configure Firebase: run `flutterfire configure` or paste generated firebase options into `lib/firebase_options.dart`.
5. Run on device/emulator: `flutter run`

NOTES:
- Location tracking and push notifications are placeholder stubs. Add geolocation & FCM packages and platform setup for full functionality.
- For production build, configure signing keys (keystore) for Android (Codemagic or local build).
