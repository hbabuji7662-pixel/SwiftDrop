
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/auth_service.dart';

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: Text('Profile')),
      body: Center(child: user==null?Text('Not logged in'):Column(mainAxisSize: MainAxisSize.min, children: [
        Text(user.email ?? ''),
        SizedBox(height:12),
        ElevatedButton(onPressed: (){ AuthService.signout().then((_) => Navigator.pushReplacementNamed(context, '/')); }, child: Text('Logout'))
      ])),
    );
  }
}
