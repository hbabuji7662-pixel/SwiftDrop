
import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class SignupPage extends StatefulWidget {
  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final email = TextEditingController();
  final pass = TextEditingController();
  bool loading = false;

  signup() async {
    setState(() => loading = true);
    final user = await AuthService.signup(email.text.trim(), pass.text.trim());
    setState(() => loading = false);
    if (user != null) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Account created, please login')));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Signup failed')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Signup')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: email, decoration: InputDecoration(labelText: 'Email')),
            TextField(controller: pass, obscureText: true, decoration: InputDecoration(labelText: 'Password')),
            SizedBox(height: 16),
            ElevatedButton(onPressed: loading?null:signup, child: loading?CircularProgressIndicator():Text('Create account')),
          ],
        ),
      ),
    );
  }
}
