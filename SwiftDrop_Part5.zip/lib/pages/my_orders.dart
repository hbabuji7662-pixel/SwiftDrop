
import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import 'package:firebase_auth/firebase_auth.dart';

class MyOrdersPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return Scaffold(body: Center(child: Text('Please login')));
    return Scaffold(
      appBar: AppBar(title: Text('My Orders')),
      body: StreamBuilder(
        stream: FirestoreService.myOrdersStream(user.uid),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs;
          if (docs.isEmpty) return Center(child: Text('No orders yet'));
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (_, i) {
              final d = docs[i].data() as Map<String, dynamic>;
              return ListTile(
                title: Text('₹' + (d['totalAmount']?.toString() ?? '0')),
                subtitle: Text(d['orderStatus'] ?? ''),
              );
            },
          );
        },
      ),
    );
  }
}
