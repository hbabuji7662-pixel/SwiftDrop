
import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import 'restaurant_view.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('SwiftDrop')),
      body: StreamBuilder(
        stream: FirestoreService.restaurantsStream(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs;
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (_, i) {
              final d = docs[i].data() as Map<String, dynamic>;
              return Card(
                child: ListTile(
                  title: Text(d['name'] ?? 'Restaurant'),
                  subtitle: Text(d['address'] ?? ''),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RestaurantView(id: docs[i].id, name: d['name']))),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
