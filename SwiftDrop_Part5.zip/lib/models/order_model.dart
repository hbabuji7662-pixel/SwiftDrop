
class OrderModel {
  final String id;
  final String customerName;
  final int totalAmount;
  final String status;
  OrderModel({required this.id, required this.customerName, required this.totalAmount, required this.status});
}
