
import 'package:flutter/material.dart';
class AppTheme {
  static const Color yellow = Color(0xFFFFD400);
  static const Color black = Color(0xFF0B0B0B);
  static ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: yellow,
    scaffoldBackgroundColor: black,
    appBarTheme: AppBarTheme(backgroundColor: black, iconTheme: IconThemeData(color: yellow)),
  );
}
