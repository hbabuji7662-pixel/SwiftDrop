
import 'package:cloud_firestore/cloud_firestore.dart';

final FirebaseFirestore firestore = FirebaseFirestore.instance;

class FirestoreService {
  // Restaurants stream
  static Stream<QuerySnapshot> restaurantsStream() {
    return firestore.collection('restaurants').snapshots();
  }

  // Menus for a restaurant
  static Stream<QuerySnapshot> menusStream(String restaurantId) {
    return firestore.collection('menus').where('restaurantId', isEqualTo: restaurantId).snapshots();
  }

  // Place order
  static Future<DocumentReference> placeOrder(Map<String, dynamic> data) {
    return firestore.collection('orders').add(data);
  }

  // My orders for a user (by phone/email)
  static Stream<QuerySnapshot> myOrdersStream(String userId) {
    return firestore.collection('orders').where('customerId', isEqualTo: userId).orderBy('createdAt', descending: true).snapshots();
  }
}
